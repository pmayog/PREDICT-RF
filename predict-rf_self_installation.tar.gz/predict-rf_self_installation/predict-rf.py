import sys
import os
import traceback

# to extract the different features
from aaindex import aaindex1
from tables import amino_acid_name, dssp_structures
from Bio.PDB import PDBParser

# to handle datasets
import numpy as np
import pandas as pd

# for loading the model
import joblib

# for evaluation
from sklearn.metrics import f1_score, confusion_matrix, ConfusionMatrixDisplay, recall_score, precision_score, roc_curve, roc_auc_score


def parseArgs():
    '''Parse command line arguments.'''
  
    import argparse

    try:
        parser = argparse.ArgumentParser(
            description='Compute ligand binding site residues within a PDB.')

        parser.add_argument('-i',
                            '--input',
                            action='store',
                            required=True,
                            help='Input must be a PDB file or a directory with at least one PDB file')

        parser.add_argument('-db',
                            '--database',
                            action='store',
                            required=True,
                            help='Specify the database used when running psiblast')
        
        parser.add_argument('-e',
                            '--eval',
                            action='store',
                            help='Specify the evale used when running psiblast. 0.001 by default')
      
        parser.add_argument('-k',
                            '--keep',
                            action='store_true',
                            help='Keep output files created by psiblast, dssp and other temporary files')
        
        parser.add_argument('-v',
                            '--verbose',
                            action='store_true',
                            help='Display information in the terminal when running the program')
    
    except:
        print ("An exception occurred with argument parsing. Check your provided options.")
        traceback.print_exc()

    return parser.parse_args()


def get_chains (pdb, quiet):
  '''Returns chains list from a PDB input file.'''
  
  if quiet == True:
    print ('Getting chains...')
  
  chains = []
  chains_new=[]
  with open(pdb, 'r') as file:
    for line in file:
      split_line=line.split()
      if 'COMPND' in split_line and 'CHAIN:' in split_line:
        chains=(split_line[3:])
        for chain in chains:
          chains_new.append(chain[0])

  return (chains_new)

def get_sequence_position (pdb, chain, quiet):
  '''Returns the residues positions list from PDB input file.'''
  
  if quiet == True:
    print ('Getting sequence positions...')
  
  all_results = []
  with open(pdb, 'r') as prot:
    for prot_line in prot:
      specific_residue = "%s %s" % (prot_line[17:20], prot_line[23:26])
      if prot_line.startswith('ATOM') and specific_residue not in all_results and chain==prot_line[21]:
        all_results.append(specific_residue)

  return (all_results)

def get_sequence (sequence_position, prefix, chain, quiet):
  ''' Returns sequence list from get_sequence_position and prefix. Also creates fasta file.'''
  
  if quiet == True:
    print ('Getting sequence...')

  name=prefix+chain+".fa"
  title=">"+ prefix+chain+"\n"
  fasta_file = open(name, 'w')
  inp=title
  count=0
  sequence=""
  for residue in sequence_position:
    res=residue[:3]
    for key, value in amino_acid_name.items():
      if res == key:
        sequence=sequence+value  

  ## Fasta file creation
  for res in sequence:
    count+=1
    if count%60 !=0:
      inp=inp+(res)
    else:
      inp=inp+res+"\n"
  inp=inp+"\n"
  fasta_file.write(inp)
  fasta_file.close()

  return (sequence)



def residue_hydrophobicity (sequence, quiet):
  '''Returns residues hydrophobicity list from aaindex1. Takes sequence as input.'''
  
  if quiet == True:
    print ('Getting residues hydrophobicity...')
  
  hydrophobicity=[]
  hydrophobicity_values = aaindex1['PRAM900101'].values
  for aa in sequence:
    for residue, values in hydrophobicity_values.items():
      if aa == residue:
        hydrophobicity.append(values)

  return (hydrophobicity)


def residue_polarity (sequence, quiet):
  '''Returns residues polarity list from aaindex1. Takes sequence as input.'''
  
  if quiet == True:
    print ('Getting residues polarity...')
  
  polarity=[]
  mean_polarity_values = aaindex1['RADA880108'].values
  for aa in sequence:
    for residue, values in mean_polarity_values.items():
      if aa == residue:
        polarity.append(values)

  return (polarity)


def residue_negative (sequence, quiet):
  '''Returns residues negative charge list from aaindex1. Takes sequence as input.'''
  
  if quiet == True:
    print ('Getting residues negative charge...')
  
  negative=[]
  negative_charge_values = aaindex1['FAUJ880112'].values
  for aa in sequence:
    for residue, values in negative_charge_values.items():
      if aa == residue:
        negative.append(values)

  return(negative)


def residue_positive (sequence, quiet):
  '''Returns residues positive charge list from aaindex1. Takes sequence as input.'''
  
  if quiet == True:
    print ('Getting residues positive charge...')
  
  positive=[]
  positive_charge_values = aaindex1['FAUJ880111'].values
  for aa in sequence:
    for residue, values in positive_charge_values.items():
      if aa == residue:
        positive.append(values)

  return (positive)
  
def residue_isoelectric_point (sequence, quiet):
  '''Returns residues isoelectric points list from aaindex1. Takes sequence as input.'''
  
  if quiet == True:
    print ('Getting residues isoelectric point...')
  
  isoelectric_point=[]
  isoelectric_point_values = aaindex1['ZIMJ680104'].values
  for aa in sequence:
    for residue, values in isoelectric_point_values.items():
      if aa == residue:
        isoelectric_point.append(values)

  return (isoelectric_point)
  


def SASA (pdb, seq_len, starting_position, quiet):
  '''Returns residues solvent-accesible surface areas (SASA) list. Takes PDB, sequence length and starting position as input.'''
  
  from SASA import ShrakeRupley
  if quiet == True:
    print ('Getting residues solvent accesible surface area...')


  new_pdb ="edited.pdb"
  new = open (new_pdb, 'w')
  with open(pdb, 'r') as file:
    for line in file:
      if line.startswith('HETATM'):
        pass
      else:
        new.write(line)

  new.close()


  sasa = []
  p = PDBParser(QUIET=1)
  struct = p.get_structure(new_pdb, new_pdb)
  sr = ShrakeRupley()
  for model in struct:
    for chain in model:
      for residue in chain:
        sr.compute(residue, level="R")
        sasa.append(round(residue.sasa, 2))

  os.remove("edited.pdb")
    
  return (sasa[starting_position:(starting_position + seq_len)])


def extract_secondary_structure(pdb, prefix, sequence, chain, quiet):
  '''Runs DSSP and returns secondary structure list from PDB, prefix, sequence length and chain inputs.'''
  
  if quiet == True:
    print ('Getting residues secondary structure...')
  
  secondary = []
  seq_started = False
  out=prefix+'_protein.dssp'

  if os.path.isfile(out):
    pass
  else:
    os.system("dssp -i" + pdb + " -o "+ out)

  index=[]
  with open(out, 'r') as out_dssp:
    for dssp_line in out_dssp:
      split_line = dssp_line.split()
      if seq_started is True:      
        if dssp_line[7:10] in sequence[4:] and dssp_line[11]==chain:
          current_structure = dssp_line[16]
          if dssp_line[16] not in dssp_structures:
            current_structure = "-"
          index.append(dssp_line[7:10])
          secondary.append(current_structure)
      elif split_line[0] == "#":
        seq_started = True

  new_seq=[]
  lacking_res =[]
  for s in sequence:
    new_seq.append(s[4:])

  if len(secondary) < len(sequence):
    for sec in new_seq:
      if sec not in index:
        lacking_res.append(new_seq.index(sec))
        
  for i in lacking_res:
    secondary.insert(i, '-')


  for i in range(len(secondary)):
      secondary[i] = secondary[i].replace('-', 'C')
      secondary[i] = secondary[i].replace('I', 'C')
      secondary[i] = secondary[i].replace('T', 'C')
      secondary[i] = secondary[i].replace('S', 'C')
      secondary[i] = secondary[i].replace('G', 'H')
      secondary[i] = secondary[i].replace('B', 'E')

  return (secondary)




def pssm_calculation (fasta_file, path_to_db, prefix, chain, eval, quiet = False):
  '''Runs Psiblast and returns pssm matrix lists and entropy list. Uses fasta file, database, prefix and chain as input.'''
  
  import math
  import subprocess
  if quiet == True:
    print('Getting PSSM...')
  

  A=[]
  R=[]
  N=[]
  D=[]
  C=[]
  Q=[]
  E=[]
  G=[]
  H=[]
  I=[]
  L=[]
  K=[]
  M=[]
  F=[]
  P=[]
  S=[]
  T=[]
  W=[]
  Y=[]
  V=[]
  entropy=[]
  out_file = prefix + chain +".pssm"
  
  if eval == False or eval == None:
    eval = str(0.001)
  else:
    eval = str(eval)

  os.system("psiblast -query " + fasta_file + " -evalue "+ eval+" -num_iterations 3 -out_ascii_pssm " +
    out_file + " -db " + path_to_db+" -out pssm.out")

  if os.path.isfile('pssm.out'):
    os.remove('pssm.out')

  if os.path.isfile(out_file)==False:
    print ('Empty PSSM...')
    return False
  
  else:
    with open (out_file, 'r') as pssm_file:
      for row in pssm_file:
        row.strip()
        split_row = row.split()
        single_entropy=0
        if 'Last' not in split_row and 'Lambda' not in split_row and 'Standard' not in split_row and 'PSI' not in split_row and len(split_row)>40:
          A.append(split_row[2])
          R.append(split_row[3])
          N.append(split_row[4])
          D.append(split_row[5])
          C.append(split_row[6])
          Q.append(split_row[7])
          E.append(split_row[8])
          G.append(split_row[9])
          H.append(split_row[10])
          I.append(split_row[11])
          L.append(split_row[12])
          K.append(split_row[13])
          M.append(split_row[14])
          F.append(split_row[15])
          P.append(split_row[16])
          S.append(split_row[17])
          T.append(split_row[18])
          W.append(split_row[19])
          Y.append(split_row[20])
          V.append(split_row[21])
          for i in range(22,42):
            if int(split_row[i]) >0:
              single_entropy = int(split_row[i])*math.log10(int(split_row[i])) + single_entropy
          entropy.append(single_entropy)


    return(A,R,N,D,C,Q,E,G,H,I,L,K,M,F,P,S,T,W,Y,V, entropy)



def generate_prediction(data_table):
  '''Loads the created ML model and it returns a dataframe with the ligand-binding residues that have been predicted and their corresponding chain.'''
  
  # Load the saved model
  joblib_RF_model = joblib.load('joblib_RandForest_undersampling_model.pkl')

  # Modify the table to be structured in the same way as the dataset of the created ML model in order to be able to predict
  # Convert to dataframe
  user_data = pd.DataFrame(data = data_table) 
  # remove residue and chain columns for the prediction
  user_data_to_predict = user_data.drop(columns=["residue", "chain"])
  # Convert the 'C', 'H' and 'E' labels for the secondary structure to numeric(0,1 and 2 respectively)
  user_data_to_predict["secondary structure"] = user_data_to_predict[
    "secondary structure"].map({
      'C': 0,
      'H': 1,
      'E': 2
    }).astype(int)
  # Round the 'entropy' values to 2 decimals
  user_data_to_predict["entropy"] = pd.to_numeric(
    user_data_to_predict["entropy"]).round(2)

  # Predict the residue type
  predictions = (joblib_RF_model.predict_proba(user_data_to_predict)[:, 1] >=
                 0.70).astype(int)

  # Create a dataframe with all residues and their type (i.e. binding or non_binding)
  residue_chain_columns = user_data[["residue","chain"]].reset_index()
  predicted_column = pd.DataFrame(({'activity': predictions}))
  result_prediction = pd.concat([residue_chain_columns, predicted_column], axis = 1)
  
  # Select the binding residues from the dataframe
  binding_residues = result_prediction.loc[result_prediction['activity'] == 1]
 
  return binding_residues

def extract_required_data_from_prediction(binding_residues):
  '''Returns two list: one in which each element contains the 3-letter residue name + residue number + chain and the other with only residue number + chain'''
  
  # Get a list with only the predicted binding residues and their corresponding chain
  binding_residues_with_chain = [f"{residue} {chain}" for i, (residue, chain) in enumerate(zip(binding_residues['residue'], binding_residues["chain"]))]
  
  # Get only the number and the chain
  res_num_chain = []
  for element in binding_residues_with_chain:
    new_element = element.split()[-2] + ' ' + element.split()[-1]
    res_num_chain.append(new_element)

  return binding_residues_with_chain, res_num_chain


def generate_ouput_files(pdb_input, binding_residues_with_chain, res_num_chain, prefix):
  '''Generates the .txt file with the list of all the residues that has been predicted that binds to the ligand and the .cmd file with the appropiate commands to be able to visualize the predicted residues in chimera.'''

  # Create a .txt file as output with the binding residues
  out_txt = prefix + "_binding_residues.txt"
  with open(out_txt, "w") as txt_file:

    for residue in binding_residues_with_chain:
      # write each residue on a new line
      txt_file.write("%s\n" % residue)

  # Close file
  # txt_file.close()

  # Create a .cmd file as output to be able to visualize the residues in chimera
  out_cmd = prefix + "_binding_residues.cmd"
  with open(out_cmd, "w") as cmd_file:
    if len(pdb_input) > 8:
      cmd_file.write(f'open {pdb_input[-8:]}\n')
    else:
      # Write the command to open the PDB file
      cmd_file.write(f'open {pdb_input}\n')
    # Delete solvent
    cmd_file.write('del solvent\n')
    # Create a molecular surface for the structure and color it white
    cmd_file.write('surf\n')
    cmd_file.write('color white,s\n')
    # Color and label the binding residues
    for residue in res_num_chain:
      resnum, chain = residue.split()
      cmd_file.write(f'color red,s :{resnum}.{chain}\n')
      cmd_file.write(f'rlabel :{resnum}.{chain}\n')



def generate_output_from_prediction(pdb_input, binding_residues, prefix):
  binding_residues_with_chain, res_num_chain = extract_required_data_from_prediction(binding_residues)
  generate_ouput_files(pdb_input, binding_residues_with_chain, res_num_chain, prefix)


def main():
  '''Compute LBS-forming residues within a PDB file.'''
  
  import pandas as pd

  ##Parse arguments  
  args = parseArgs()
  pdb = args.input
  path_to_db = args.database
  eval = args.eval
  keep = args.keep
  quiet = args.verbose

  if os.path.isdir(pdb):
    if pdb.endswith("/"):
      pass
    else:
      pdb=pdb+"/"
    for pdb_file in os.listdir(pdb):
      pdb_table=pd.DataFrame()
      result=pd.DataFrame()
      starting_position = 0
      if pdb_file.endswith(".pdb"):
        prefix = str(pdb_file.replace('.pdb',''))
        if quiet == True:
          print('Starting with:', prefix)
        if  pdb != '.' or pdb != './':
          pdb_file=str(pdb+pdb_file)
        chains=get_chains(pdb_file, quiet)
        for chain in sorted(chains):
          fasta_file = prefix + chain +".fa"
          output=prefix+chain+".csv"

          ##Calling the functions and putting their results into lists
          sequence_residues = get_sequence_position (pdb_file, chain, quiet)
          sequence = get_sequence (sequence_residues, prefix, chain, quiet)
          hydrophobicity = residue_hydrophobicity (sequence, quiet)
          polarity = residue_polarity (sequence, quiet)
          positive = residue_positive (sequence, quiet)
          negative = residue_negative (sequence, quiet)
          isoelectric_point = residue_isoelectric_point (sequence, quiet)
          secondary_structure = extract_secondary_structure(pdb_file,prefix, sequence_residues, chain, quiet)
          sasa = SASA(pdb_file, len(sequence), starting_position, quiet)
          pssm = pssm_calculation (fasta_file, path_to_db, prefix, chain, eval, quiet)
          starting_position = len(sequence) + starting_position

          ##Creating chain list (added to the table)
          chain_res = []
          for res in sequence_residues:
            chain_res.append(chain)

          ##Removing output files from DSSP and psiblast and other tmp files if -del option is entered
          if keep == False:
            if pssm == False:
              files = [prefix+chain+".fa", prefix+"_protein.dssp"]
              for f in files:
                os.remove(f)
            else:
              files = [prefix+chain+".fa", prefix+"_protein.dssp",prefix+chain+".pssm"]
              for f in files:
                os.remove(f)
          

          if pssm == False:
            table = {}
            print ('Skipping chain...')
            continue

          else:
          ##Creating the dataframe with the previous lists
            table = {
                  'residue': sequence_residues,
                  'chain': chain_res,
                  'hydrophobicity': hydrophobicity,
                  'polarity': polarity,
                  'positive': positive,
                  'negative': negative,
                  'isoelectric point': isoelectric_point,
                  'secondary structure': secondary_structure,
                  'sasa': sasa,
                  'A':pssm[0],
                  'R':pssm[1],
                  'N':pssm[2],
                  'D':pssm[3],
                  'C':pssm[4],
                  'Q':pssm[5],
                  'E':pssm[6],
                  'G':pssm[7],
                  'H':pssm[8],
                  'I':pssm[9],
                  'L':pssm[10],
                  'K':pssm[11],
                  'M':pssm[12],
                  'F':pssm[13],
                  'P':pssm[14],
                  'S':pssm[15],
                  'T':pssm[16],
                  'W':pssm[17],
                  'Y':pssm[18],
                  'V':pssm[19],
                  'entropy':pssm[20],
            }

            result=pd.DataFrame(data=table)
            pdb_table = pd.concat([pdb_table,result])

        if not result.empty:
          binding_residues = generate_prediction(data_table=pdb_table)
          generate_output_from_prediction(pdb_file, binding_residues, prefix)
          
      else:
        print('Skipping file. Input must contain PDB file/s.')

        

  else:
    if pdb.endswith('.pdb'):
      starting_position = 0
      prefix = str(pdb.replace('.pdb',''))
      if quiet == True:
          print('Starting with:', prefix)
      chains=get_chains(pdb, quiet)
      result=pd.DataFrame()
      pdb_table=pd.DataFrame()
      for chain in chains:
        fasta_file = prefix + chain +".fa"
        output=prefix+chain+".csv"

        ##Calling the functions and putting their results into lists
        sequence_residues = get_sequence_position (pdb, chain, quiet)
        sequence = get_sequence (sequence_residues, prefix, chain, quiet)
        hydrophobicity = residue_hydrophobicity (sequence, quiet)
        polarity = residue_polarity (sequence, quiet)
        positive = residue_positive (sequence, quiet)
        negative = residue_negative (sequence, quiet)
        isoelectric_point = residue_isoelectric_point (sequence, quiet)
        secondary_structure = extract_secondary_structure(pdb, prefix,sequence_residues, chain, quiet)
        sasa = SASA(pdb, len(sequence), starting_position, quiet)
        pssm = pssm_calculation (fasta_file, path_to_db, prefix, chain, eval, quiet)
        starting_position = len(sequence) + starting_position

        ##Creating chain list (added to the table)
        chain_res = []
        for res in sequence_residues:
          chain_res.append(chain)

        ##Removing output files from DSSP and psiblast and other tmp files if -del option is entered
        if keep == False:
            if pssm == False:
              files = [prefix+chain+".fa", prefix+"_protein.dssp"]
              for f in files:
                os.remove(f)
            else:
              files = [prefix+chain+".fa", prefix+"_protein.dssp",prefix+chain+".pssm"]
              for f in files:
                os.remove(f)
      
        if pssm == False:
          table = {}
          print ('Skipping chain...')
          continue

        else:
        ##Creating the dataframe with the previous lists
          table = {
                'residue': sequence_residues,
                'chain': chain_res,
                'hydrophobicity': hydrophobicity,
                'polarity': polarity,
                'positive': positive,
                'negative': negative,
                'isoelectric point': isoelectric_point,
                'secondary structure': secondary_structure,
                'sasa': sasa,
                'A':pssm[0],
                'R':pssm[1],
                'N':pssm[2],
                'D':pssm[3],
                'C':pssm[4],
                'Q':pssm[5],
                'E':pssm[6],
                'G':pssm[7],
                'H':pssm[8],
                'I':pssm[9],
                'L':pssm[10],
                'K':pssm[11],
                'M':pssm[12],
                'F':pssm[13],
                'P':pssm[14],
                'S':pssm[15],
                'T':pssm[16],
                'W':pssm[17],
                'Y':pssm[18],
                'V':pssm[19],
                'entropy':pssm[20],
            }

          result=pd.DataFrame(data=table)
          pdb_table = pd.concat([pdb_table,result])

      if not result.empty:
        ##Calling prediction functions
        binding_residues = generate_prediction(data_table=pdb_table)
        generate_output_from_prediction(pdb, binding_residues, prefix)
  

    else:
      print('Skipping file. Input must be a PDB file.')




if __name__ == '__main__':
  main()
